Ques 2 -> Count Inversion problem

Ques 3 -> Producer Consumer problem

Ques 4 -> Multi threaded key value store library


-> Testing code of last question is given in the .cpp file withing comments.